create definer = po_sdc1011@`%` view view_datacenter_userdeptpost as
select `users`.`username` AS `username`, `dept`.`code` AS `dept_code`, `post`.`name` AS `post_name`
from ((((`bjtu_po_management`.`dvadmin_system_users_deptpost` `users_deptpost` left join `bjtu_po_management`.`dvadmin_system_deptpost` `deptpost`
         on ((`users_deptpost`.`deptpost_id` = `deptpost`.`id`))) left join `bjtu_po_management`.`dvadmin_system_dept` `dept`
        on ((`deptpost`.`dept_id` = `dept`.`id`))) left join `bjtu_po_management`.`dvadmin_system_post` `post`
       on ((`deptpost`.`post_id` = `post`.`id`))) left join `bjtu_po_management`.`dvadmin_system_users` `users`
      on ((`users_deptpost`.`users_id` = `users`.`id`)));

-- comment on column view_datacenter_userdeptpost.username not supported: 学工号

-- comment on column view_datacenter_userdeptpost.dept_code not supported: 部门编号

-- comment on column view_datacenter_userdeptpost.post_name not supported: 岗位名称

