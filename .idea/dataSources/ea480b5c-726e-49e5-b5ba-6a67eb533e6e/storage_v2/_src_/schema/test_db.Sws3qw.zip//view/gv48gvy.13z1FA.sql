create definer = sdc1011@`%` view gv48gvy as
select sha(concat(`test_db`.`jxj_tjb`.`wid`, '20231229154855'))   AS `wid`,
       sha(concat(`test_db`.`jxj_tjb`.`xsbh`, '20231229154855'))  AS `xsbh`,
       sha(concat(`test_db`.`jxj_tjb`.`xm`, '20231229154855'))    AS `xm`,
       sha(concat(`test_db`.`jxj_tjb`.`xbmc`, '20231229154855'))  AS `xbmc`,
       sha(concat(`test_db`.`jxj_tjb`.`sfzjh`, '20231229154855')) AS `sfzjh`,
       sha(concat(`test_db`.`jxj_tjb`.`xnxsz`, '20231229154855')) AS `xnxsz`,
       sha(concat(`test_db`.`jxj_tjb`.`jxjmc`, '20231229154855')) AS `jxjmc`,
       sha(concat(`test_db`.`jxj_tjb`.`je`, '20231229154855'))    AS `je`,
       sha(concat(`test_db`.`jxj_tjb`.`djmc`, '20231229154855'))  AS `djmc`,
       sha(concat(`test_db`.`jxj_tjb`.`dwjc`, '20231229154855'))  AS `dwjc`,
       sha(concat(`test_db`.`jxj_tjb`.`zymc`, '20231229154855'))  AS `zymc`,
       sha(concat(`test_db`.`jxj_tjb`.`bjdm`, '20231229154855'))  AS `bjdm`
from `test_db`.`jxj_tjb`;

