create definer = sdc1011@`%` view vl0dhwf as
select sha(concat(`test_db`.`jxj_tjb`.`wid`, '20231229163939'))   AS `wid`,
       sha(concat(`test_db`.`jxj_tjb`.`xsbh`, '20231229163939'))  AS `xsbh`,
       sha(concat(`test_db`.`jxj_tjb`.`xm`, '20231229163939'))    AS `xm`,
       sha(concat(`test_db`.`jxj_tjb`.`xbmc`, '20231229163939'))  AS `xbmc`,
       sha(concat(`test_db`.`jxj_tjb`.`sfzjh`, '20231229163939')) AS `sfzjh`,
       sha(concat(`test_db`.`jxj_tjb`.`xnxsz`, '20231229163939')) AS `xnxsz`,
       sha(concat(`test_db`.`jxj_tjb`.`jxjmc`, '20231229163939')) AS `jxjmc`,
       sha(concat(`test_db`.`jxj_tjb`.`je`, '20231229163939'))    AS `je`,
       sha(concat(`test_db`.`jxj_tjb`.`djmc`, '20231229163939'))  AS `djmc`,
       sha(concat(`test_db`.`jxj_tjb`.`dwjc`, '20231229163939'))  AS `dwjc`,
       sha(concat(`test_db`.`jxj_tjb`.`zymc`, '20231229163939'))  AS `zymc`,
       sha(concat(`test_db`.`jxj_tjb`.`bjdm`, '20231229163939'))  AS `bjdm`
from `test_db`.`jxj_tjb`;

