create definer = po_sdc1011@`172.27.%.%` view view_users_createtime as
select `u`.`name`              AS `name`,
       `u`.`username`          AS `username`,
       `u`.`gender`            AS `gender`,
       `u`.`user_type`         AS `user_type`,
       `u`.`mobile`            AS `mobile`,
       `u`.`email`             AS `email`,
       `u`.`political_outlook` AS `political_outlook`,
       `u`.`nation`            AS `nation`,
       `d`.`code`              AS `dept_code`,
       `u`.`create_datetime`   AS `create_datetime`
from (`bjtu_po_management`.`dvadmin_system_users` `u` left join `bjtu_po_management`.`dvadmin_system_dept` `d`
      on ((`u`.`dept_id` = `d`.`id`)));

-- comment on column view_users_createtime.name not supported: 姓名

-- comment on column view_users_createtime.username not supported: 学工号

-- comment on column view_users_createtime.gender not supported: 性别

-- comment on column view_users_createtime.user_type not supported: 用户类型

-- comment on column view_users_createtime.mobile not supported: 手机号

-- comment on column view_users_createtime.email not supported: 邮箱

-- comment on column view_users_createtime.political_outlook not supported: 政治面貌

-- comment on column view_users_createtime.nation not supported: 民族

-- comment on column view_users_createtime.dept_code not supported: 部门编号

-- comment on column view_users_createtime.create_datetime not supported: 创建时间

