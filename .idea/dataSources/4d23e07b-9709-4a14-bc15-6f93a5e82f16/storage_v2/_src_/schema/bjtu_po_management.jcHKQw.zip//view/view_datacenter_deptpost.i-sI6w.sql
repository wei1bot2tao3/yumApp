create definer = po_sdc1011@`%` view view_datacenter_deptpost as
select `deptpost`.`dept_id` AS `dept_id`,
       `deptpost`.`post_id` AS `post_id`,
       `dept`.`name`        AS `dept_name`,
       `post`.`name`        AS `post_name`
from ((`bjtu_po_management`.`dvadmin_system_deptpost` `deptpost` left join `bjtu_po_management`.`dvadmin_system_post` `post`
       on ((`deptpost`.`post_id` = `post`.`id`))) left join `bjtu_po_management`.`dvadmin_system_dept` `dept`
      on ((`deptpost`.`dept_id` = `dept`.`id`)));

-- comment on column view_datacenter_deptpost.dept_id not supported: 关联组织

-- comment on column view_datacenter_deptpost.post_id not supported: 关联岗位

-- comment on column view_datacenter_deptpost.dept_name not supported: 部门/组织名称

-- comment on column view_datacenter_deptpost.post_name not supported: 岗位名称

