create definer = sdc1011@`%` view l762hza6gq7zergq061huu as
select sha(concat(`test_db`.`auth_group_permissions`.`id`, '20231229163853'))            AS `id`,
       sha(concat(`test_db`.`auth_group_permissions`.`group_id`, '20231229163853'))      AS `group_id`,
       sha(concat(`test_db`.`auth_group_permissions`.`permission_id`, '20231229163853')) AS `permission_id`
from `test_db`.`auth_group_permissions`;

