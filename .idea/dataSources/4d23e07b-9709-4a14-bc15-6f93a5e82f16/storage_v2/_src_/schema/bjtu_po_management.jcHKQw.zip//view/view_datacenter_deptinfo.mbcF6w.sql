create definer = po_sdc1011@`%` view view_datacenter_deptinfo as
select `a`.`name` AS `name`, `a`.`code` AS `code`, `b`.`code` AS `parent_code`
from (`bjtu_po_management`.`dvadmin_system_dept` `a` left join `bjtu_po_management`.`dvadmin_system_dept` `b`
      on ((`a`.`parent_id` = `b`.`id`)));

-- comment on column view_datacenter_deptinfo.name not supported: 部门/组织名称

-- comment on column view_datacenter_deptinfo.code not supported: 部门编号

-- comment on column view_datacenter_deptinfo.parent_code not supported: 部门编号

