create definer = po_sdc1011@`%` view view_user_class_info as
select `dsu`.`username`                                AS `username`,
       `ss`.`major`                                    AS `major`,
       `ss`.`class_name`                               AS `class_name`,
       cast(substr(`dsu`.`id_card_num`, 7, 8) as date) AS `birthday`
from (`bjtu_po_management`.`dvadmin_system_users` `dsu` left join `bjtu_po_management`.`system_student` `ss`
      on ((`dsu`.`username` = `ss`.`username`)))
where ((`dsu`.`user_type` = 0) or (`dsu`.`user_type` = 1));

-- comment on column view_user_class_info.username not supported: 学工号

-- comment on column view_user_class_info.major not supported: 专业

-- comment on column view_user_class_info.class_name not supported: 班级

