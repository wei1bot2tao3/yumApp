create definer = po_sdc1011@`%` view view_in_school_student as
select `u`.`username` AS `username`, `u`.`name` AS `name`, `d`.`name` AS `d_name`
from (`bjtu_po_management`.`dvadmin_system_users` `u` left join `bjtu_po_management`.`dvadmin_system_dept` `d`
      on ((`u`.`dept_id` = `d`.`id`)))
where ((`u`.`user_type` = 1) and (`u`.`in_school` = 1));

-- comment on column view_in_school_student.username not supported: 学工号

-- comment on column view_in_school_student.name not supported: 姓名

-- comment on column view_in_school_student.d_name not supported: 部门/组织名称

