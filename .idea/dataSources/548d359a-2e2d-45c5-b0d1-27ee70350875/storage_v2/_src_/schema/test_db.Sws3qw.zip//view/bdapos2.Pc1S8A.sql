create definer = sdc1011@`%` view bdapos2 as
select `test_db`.`jxj_tjb`.`wid`        AS `wid`,
       md5(`test_db`.`jxj_tjb`.`xsbh`)  AS `xsbh`,
       `test_db`.`jxj_tjb`.`xm`         AS `xm`,
       md5(`test_db`.`jxj_tjb`.`xbmc`)  AS `xbmc`,
       md5(`test_db`.`jxj_tjb`.`sfzjh`) AS `sfzjh`,
       md5(`test_db`.`jxj_tjb`.`xnxsz`) AS `xnxsz`,
       md5(`test_db`.`jxj_tjb`.`jxjmc`) AS `jxjmc`,
       `test_db`.`jxj_tjb`.`je`         AS `je`,
       md5(`test_db`.`jxj_tjb`.`djmc`)  AS `djmc`,
       `test_db`.`jxj_tjb`.`dwjc`       AS `dwjc`,
       md5(`test_db`.`jxj_tjb`.`zymc`)  AS `zymc`,
       md5(`test_db`.`jxj_tjb`.`bjdm`)  AS `bjdm`
from `test_db`.`jxj_tjb`;

-- comment on column bdapos2.xm not supported: 姓名

-- comment on column bdapos2.je not supported: 金额

-- comment on column bdapos2.dwjc not supported: 学院

