create definer = po_sdc1011@`172.27.%.%` view view_users_info as
select `u`.`name`     AS `name`,
       `u`.`username` AS `username`,
       `u`.`mobile`   AS `mobile`,
       `u`.`email`    AS `email`,
       `d`.`name`     AS `dept_name`,
       `d`.`code`     AS `dept_code`
from (`bjtu_po_management`.`dvadmin_system_users` `u` left join `bjtu_po_management`.`dvadmin_system_dept` `d`
      on ((`u`.`dept_id` = `d`.`id`)))
where (`u`.`teacher_id` is not null);

-- comment on column view_users_info.name not supported: 姓名

-- comment on column view_users_info.username not supported: 学工号

-- comment on column view_users_info.mobile not supported: 手机号

-- comment on column view_users_info.email not supported: 邮箱

-- comment on column view_users_info.dept_name not supported: 部门/组织名称

-- comment on column view_users_info.dept_code not supported: 部门编号

