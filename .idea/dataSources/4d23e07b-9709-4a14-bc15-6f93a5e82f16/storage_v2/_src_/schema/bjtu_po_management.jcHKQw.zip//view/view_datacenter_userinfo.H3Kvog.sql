create definer = po_sdc1011@`%` view view_datacenter_userinfo as
select `users`.`username`                                                                                           AS `username`,
       `users`.`name`                                                                                               AS `NAME`,
       `dept`.`code`                                                                                                AS `dept_code`,
       `users`.`gender`                                                                                             AS `gender`,
       `users`.`mobile`                                                                                             AS `mobile`,
       `student`.`grade`                                                                                            AS `grade`,
       `student`.`instructor_name`                                                                                  AS `instructor_name`,
       `student`.`instructor_code`                                                                                  AS `instructor_code`,
       `student`.`instructor_mobile`                                                                                AS `instructor_mobile`,
       `student`.`student_status`                                                                                   AS `student_status`,
       if((`users`.`student_id` is not null), (case
                                                   when (`student`.`training_level` = '01') then '博士'
                                                   when (`student`.`training_level` = '02') then '硕士'
                                                   when (`student`.`training_level` = '03') then '本科'
                                                   when (`student`.`training_level` = '04') then '高职'
                                                   when (`student`.`training_level` = '05') then '中小学幼儿园学生'
                                                   when (`student`.`training_level` = '81') then '在校内临时交流访问、参加培训或留住学生'
                                                   when (`student`.`training_level` = '82') then '其他在校内居住或留住的学生'
                                                   when (`student`.`training_level` = '99') then '其他' end),
          if((`users`.`teacher_id` is not null), (case
                                                      when (`teacher`.`teacher_type` = '01') then '在职教职工'
                                                      when (`teacher`.`teacher_type` = '02') then '离退休'
                                                      when (`teacher`.`teacher_type` = '03') then '其他校外人员'
                                                      when (`teacher`.`teacher_type` = '04') then '离职' end),
             ''))                                                                                                   AS `training_level`,
       `student`.`dormitory_building`                                                                               AS `dormitory_building`,
       `student`.`dormitory_floor`                                                                                  AS `dormitory_floor`,
       `student`.`dormitory_room`                                                                                   AS `dormitory_room`,
       if((`users`.`user_type` = 0), '教职工', '学生')                                                              AS `user_type`,
       `users`.`in_school`                                                                                          AS `in_school`
from ((((`bjtu_po_management`.`dvadmin_system_users` `users` left join `bjtu_po_management`.`system_student` `student`
         on ((`users`.`student_id` = `student`.`id`))) left join `bjtu_po_management`.`system_teacher` `teacher`
        on ((`users`.`teacher_id` = `teacher`.`id`))) left join `bjtu_po_management`.`dvadmin_system_users_deptpost` `users_deptpost`
       on ((`users`.`id` = `users_deptpost`.`users_id`))) left join `bjtu_po_management`.`dvadmin_system_dept` `dept`
      on ((`users`.`dept_id` = `dept`.`id`)))
where ((`users`.`username` <> 'superadmin') and (`users`.`username` <> 'rscsuperadmin') and
       (((`users`.`user_type` = 0) and (`teacher`.`teacher_type` <> '02') and (`teacher`.`teacher_type` <> '04')) or
        (`users`.`user_type` = 1)));

-- comment on column view_datacenter_userinfo.username not supported: 学工号

-- comment on column view_datacenter_userinfo.NAME not supported: 姓名

-- comment on column view_datacenter_userinfo.dept_code not supported: 部门编号

-- comment on column view_datacenter_userinfo.gender not supported: 性别

-- comment on column view_datacenter_userinfo.mobile not supported: 手机号

-- comment on column view_datacenter_userinfo.grade not supported: 年级 如：2021

-- comment on column view_datacenter_userinfo.instructor_name not supported: 辅导员姓名

-- comment on column view_datacenter_userinfo.instructor_code not supported: 辅导员工号

-- comment on column view_datacenter_userinfo.instructor_mobile not supported: 辅导员联系方式

-- comment on column view_datacenter_userinfo.student_status not supported: 学籍状态

-- comment on column view_datacenter_userinfo.dormitory_building not supported: 宿舍楼

-- comment on column view_datacenter_userinfo.dormitory_floor not supported: 宿舍楼层

-- comment on column view_datacenter_userinfo.dormitory_room not supported: 宿舍号

-- comment on column view_datacenter_userinfo.in_school not supported: 是否在校

