create definer = po_sdc1011@`172.27.%.%` view view_users as
select `u`.`name`              AS `name`,
       `u`.`username`          AS `username`,
       `u`.`gender`            AS `gender`,
       `u`.`user_type`         AS `user_type`,
       `u`.`mobile`            AS `mobile`,
       `u`.`email`             AS `email`,
       `u`.`political_outlook` AS `political_outlook`,
       `u`.`nation`            AS `nation`,
       `d`.`code`              AS `dept_code`
from (`bjtu_po_management`.`dvadmin_system_users` `u` left join `bjtu_po_management`.`dvadmin_system_dept` `d`
      on ((`u`.`dept_id` = `d`.`id`)));

-- comment on column view_users.name not supported: 姓名

-- comment on column view_users.username not supported: 学工号

-- comment on column view_users.gender not supported: 性别

-- comment on column view_users.user_type not supported: 用户类型

-- comment on column view_users.mobile not supported: 手机号

-- comment on column view_users.email not supported: 邮箱

-- comment on column view_users.political_outlook not supported: 政治面貌

-- comment on column view_users.nation not supported: 民族

-- comment on column view_users.dept_code not supported: 部门编号

