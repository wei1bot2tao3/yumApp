create definer = po_sdc1011@`%` view view_eighthours as
select `u`.`name`                                                             AS `name`,
       if((`u`.`gender` = '1'), '男', if((`u`.`gender` = '2'), '女', '未知')) AS `gender`,
       timestampdiff(YEAR, substr(`u`.`id_card_num`, 7, 8), now())            AS `age`,
       cast(substr(`u`.`id_card_num`, 7, 8) as date)                          AS `birthday`,
       (case
            when (`u`.`id_card_type` = '01') then '身份证'
            when (`u`.`id_card_type` = '02') then '军官证'
            when (`u`.`id_card_type` = '03') then '护照'
            when (`u`.`id_card_type` = '04') then '外国人永久居留身份证'
            when (`u`.`id_card_type` = '05') then '港澳居民来往内地通行证'
            when (`u`.`id_card_type` = '06') then '台湾居民来往大陆通行证'
            when (`u`.`id_card_type` = '15') then '港澳居民居住证（香港）'
            when (`u`.`id_card_type` = '16') then '港澳居民居住证（澳门）'
            when (`u`.`id_card_type` = '17') then '台湾居民居住证'
            when (`u`.`id_card_type` = '99') then '其他' end)                 AS `id_card_type`,
       `u`.`id_card_num`                                                      AS `id_card_num`,
       `u`.`mobile`                                                           AS `mobile`,
       `t`.`permanent_residence`                                              AS `permanent_residence`,
       `t`.`actual_residence`                                                 AS `actual_residence`,
       `u`.`is_permanent_residence`                                           AS `is_permanent_residence`,
       `u`.`campus`                                                           AS `campus`,
       `d`.`name`                                                             AS `dept_name`,
       `d`.`id`                                                               AS `dept_id`,
       `d`.`code`                                                             AS `dept_code`,
       `s`.`class_name`                                                       AS `class_name`,
       `s`.`dormitory_building`                                               AS `dormitory_building`,
       `s`.`dormitory_room`                                                   AS `dormitory_room`,
       if((`u`.`user_type` = '0'), '教职工', '学生')                          AS `user_type`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.vaccinationFlag'),
                                                              '"', '')
            else '' end)                                                      AS `vaccinationFlag`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.dyzympp'), '"', '')
            else '' end)                                                      AS `dyzympp`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.dyzjzsj'), '"', '')
            else '' end)                                                      AS `dyzjzsj`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.dezjzsj'), '"', '')
            else '' end)                                                      AS `dezjzsj`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.dszjzsj'), '"', '')
            else '' end)                                                      AS `dszjzsj`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.wjzyy'), '"', '')
            else '' end)                                                      AS `wjzyy`,
       `ue`.`last_in_beijing_time`                                            AS `last_in_beijing_time`,
       `ue`.`in_beijing_address`                                              AS `in_beijing_address`,
       (case
            when json_valid(`ue`.`vaccine_info`) then replace(json_extract(`ue`.`vaccine_info`, '$.remark'), '"', '')
            else '' end)                                                      AS `remark`
from ((((`bjtu_po_management`.`dvadmin_system_users` `u` left join `bjtu_po_management`.`system_teacher` `t`
         on ((`u`.`teacher_id` = `t`.`id`))) left join `bjtu_po_management`.`system_student` `s`
        on ((`u`.`student_id` = `s`.`id`))) left join `bjtu_po_management`.`system_users_extra` `ue`
       on ((`u`.`username` = `ue`.`username`))) left join `bjtu_po_management`.`dvadmin_system_dept` `d`
      on ((`u`.`dept_id` = `d`.`id`)));

-- comment on column view_eighthours.name not supported: 姓名

-- comment on column view_eighthours.id_card_num not supported: 身份证号

-- comment on column view_eighthours.mobile not supported: 手机号

-- comment on column view_eighthours.permanent_residence not supported: 户籍地址

-- comment on column view_eighthours.actual_residence not supported: 实际居住地

-- comment on column view_eighthours.is_permanent_residence not supported: 是否常住学校

-- comment on column view_eighthours.campus not supported: 所在校区

-- comment on column view_eighthours.dept_name not supported: 部门/组织名称

-- comment on column view_eighthours.dept_id not supported: Id

-- comment on column view_eighthours.dept_code not supported: 部门编号

-- comment on column view_eighthours.class_name not supported: 班级

-- comment on column view_eighthours.dormitory_building not supported: 宿舍楼

-- comment on column view_eighthours.dormitory_room not supported: 宿舍号

-- comment on column view_eighthours.last_in_beijing_time not supported: 最近一次进京日期

-- comment on column view_eighthours.in_beijing_address not supported: 从何地进京

