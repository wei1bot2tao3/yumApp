create definer = po_sdc1011@`219.242.113.%` view grade as
select `bjtu_po_management`.`system_student`.`username`        AS `username`,
       `bjtu_po_management`.`system_student`.`grade`           AS `grade`,
       `bjtu_po_management`.`system_student`.`instructor_name` AS `instructor_name`,
       `bjtu_po_management`.`system_student`.`instructor_code` AS `instructor_code`
from `bjtu_po_management`.`system_student`
where (`bjtu_po_management`.`system_student`.`grade` not in (2017, 2018, 2019, 2020, 2021, 2022));

-- comment on column grade.username not supported: 学工号

-- comment on column grade.grade not supported: 年级 如：2021

-- comment on column grade.instructor_name not supported: 辅导员姓名

-- comment on column grade.instructor_code not supported: 辅导员工号

