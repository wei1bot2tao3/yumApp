create definer = po_sdc1011@`172.27.%.%` view view_users_type as
select `users`.`username`                                                                                           AS `username`,
       `users`.`name`                                                                                               AS `NAME`,
       `dept`.`name`                                                                                                AS `deptName`,
       if((`users`.`gender` = '1'), '男',
          if((`users`.`gender` = '2'), '女', '未知'))                                                               AS `gender`,
       `users`.`mobile`                                                                                             AS `mobile`,
       if((`users`.`student_id` is not null), (case
                                                   when (`student`.`training_level` = '01') then '博士'
                                                   when (`student`.`training_level` = '02') then '硕士'
                                                   when (`student`.`training_level` = '03') then '本科'
                                                   when (`student`.`training_level` = '04') then '高职'
                                                   when (`student`.`training_level` = '05') then '中小学幼儿园学生'
                                                   when (`student`.`training_level` = '81') then '在校内临时交流访问、参加培训或留住学生'
                                                   when (`student`.`training_level` = '82') then '其他在校内居住或留住的学生'
                                                   when (`student`.`training_level` = '99') then '其他' end),
          if((`users`.`teacher_id` is not null), (case
                                                      when (`teacher`.`teacher_type` = '01') then '在职教职工'
                                                      when (`teacher`.`teacher_type` = '02') then '离退休'
                                                      when (`teacher`.`teacher_type` = '03') then '其他校外人员'
                                                      when (`teacher`.`teacher_type` = '04') then '离职' end),
             ''))                                                                                                   AS `userType`
from (((`bjtu_po_management`.`dvadmin_system_users` `users` left join `bjtu_po_management`.`dvadmin_system_dept` `dept`
        on ((`users`.`dept_id` = `dept`.`id`))) left join `bjtu_po_management`.`system_student` `student`
       on (((`users`.`username` = `student`.`username`) and
            (`users`.`student_id` is not null)))) left join `bjtu_po_management`.`system_teacher` `teacher`
      on (((`users`.`username` = `teacher`.`username`) and (`users`.`teacher_id` is not null))));

-- comment on column view_users_type.username not supported: 学工号

-- comment on column view_users_type.NAME not supported: 姓名

-- comment on column view_users_type.deptName not supported: 部门/组织名称

-- comment on column view_users_type.mobile not supported: 手机号

