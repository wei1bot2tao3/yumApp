create definer = po_sdc1011@`172.27.%.%` view view_student_adviser as
select `dsu`.`name`           AS `student_name`,
       `dsu`.`username`       AS `student_number`,
       `dsd`.`name`           AS `student_department`,
       `ss`.`instructor_name` AS `adviser_name`,
       `ss`.`instructor_code` AS `adviser_number`
from ((`bjtu_po_management`.`dvadmin_system_users` `dsu` left join `bjtu_po_management`.`system_student` `ss`
       on ((`dsu`.`username` = `ss`.`username`))) left join `bjtu_po_management`.`dvadmin_system_dept` `dsd`
      on ((`dsu`.`dept_id` = `dsd`.`id`)))
where (`dsu`.`user_type` = 1);

-- comment on column view_student_adviser.student_name not supported: 姓名

-- comment on column view_student_adviser.student_number not supported: 学工号

-- comment on column view_student_adviser.student_department not supported: 部门/组织名称

-- comment on column view_student_adviser.adviser_name not supported: 辅导员姓名

-- comment on column view_student_adviser.adviser_number not supported: 辅导员工号

