create definer = po_sdc1011@`172.27.%.%` view view_dept as
select `a`.`name` AS `name`, `a`.`code` AS `code`, `b`.`code` AS `parentCode`
from (`bjtu_po_management`.`dvadmin_system_dept` `a` left join `bjtu_po_management`.`dvadmin_system_dept` `b`
      on ((`a`.`parent_id` = `b`.`id`)));

-- comment on column view_dept.name not supported: 部门/组织名称

-- comment on column view_dept.code not supported: 部门编号

-- comment on column view_dept.parentCode not supported: 部门编号

