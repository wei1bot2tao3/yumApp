create definer = po_sdc1011@`172.27.%.%` view test as
select `a`.`name` AS `name`, `a`.`code` AS `code`, `b`.`code` AS `parentCode`
from (`bjtu_po_management`.`dvadmin_system_dept` `a` left join `bjtu_po_management`.`dvadmin_system_dept` `b`
      on ((`a`.`parent_id` = `b`.`id`)));

-- comment on column test.name not supported: 部门/组织名称

-- comment on column test.code not supported: 部门编号

-- comment on column test.parentCode not supported: 部门编号

