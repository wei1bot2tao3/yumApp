create definer = po_sdc1011@`172.27.%.%` view view_users_post as
select `dsd`.`post_id` AS `post_id`, `dsu`.`username` AS `username`
from ((`bjtu_po_management`.`dvadmin_system_users_deptpost` `dsud` left join `bjtu_po_management`.`dvadmin_system_users` `dsu`
       on ((`dsud`.`users_id` = `dsu`.`id`))) left join `bjtu_po_management`.`dvadmin_system_deptpost` `dsd`
      on ((`dsud`.`deptpost_id` = `dsd`.`id`)));

-- comment on column view_users_post.post_id not supported: 关联岗位

-- comment on column view_users_post.username not supported: 学工号

